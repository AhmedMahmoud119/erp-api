<?php


return [

    'compact'=>'ultra',
    'apiKey'=>'4e169e31d96998e3238f',
    'regex'=>'/^[a-zA-Zگچپژیلفقهكيىموي ء-ي\s]*$/'

];
