<?php

namespace App\Domains\Language\Interfaces;

use App\Domains\Language\Models\Language;
use Illuminate\Database\Eloquent\Collection;

interface LanguageRepositoryInterface
{
}
