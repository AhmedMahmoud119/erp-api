<?php

namespace App\Domains\Language\Repositories;

use App\Domains\Language\Interfaces\LanguageRepositoryInterface;

class LanguageMySqlRepository implements LanguageRepositoryInterface
{
}
