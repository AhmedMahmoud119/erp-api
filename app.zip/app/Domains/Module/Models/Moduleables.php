<?php

namespace App\Domains\Module\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Moduleables extends Model
{
    use HasFactory;
}
