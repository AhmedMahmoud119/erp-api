<?php

namespace App\Domains\Module\Services;


use App\Domains\Module\Interfaces\ModuleRepositoryInterface;

class ModuleService
{

}
