<?php

namespace App\Domains\Module\Interfaces;

use App\Domains\Module\Models\Module;
use Illuminate\Database\Eloquent\Collection;

interface ModuleRepositoryInterface
{
}
