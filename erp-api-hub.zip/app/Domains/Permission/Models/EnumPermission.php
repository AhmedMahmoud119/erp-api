<?php

namespace App\Domains\Permission\Models;

enum EnumPermission: string
{
    case view_permissions = 'View Permissions';

}
