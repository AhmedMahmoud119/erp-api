<?php

namespace App\Domains\Module\Controllers;

use App\Http\Controllers\Controller;

class ModuleController extends Controller
{

}
